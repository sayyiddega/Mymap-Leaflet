<div class="main-menu-content"><a class="navigation-brand d-none d-md-block d-lg-block d-xl-block" href="index.php"><img class="brand-logo" alt="CryptoDash admin logo" src="../../../app-assets/images/logo/logo.png"/></a>
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">
          <li class="active"><a href="index.php"><i class="icon-grid"></i><span class="menu-title" data-i18n="">Dashboard</span></a>
          </li>
          <li class=" nav-item"><a href="petaku/petaku.php"><i class="icon-layers"></i><span class="menu-title" data-i18n="">Peta</span></a>
          </li>
          <li class=" nav-item"><a href="dataaset.php"><i class="icon-wallet"></i><span class="menu-title" data-i18n="">Daftar Tanah</span></a>
          </li>       
          <li class=" nav-item"><a href="#"><i class="icon-user-following"></i><span class="menu-title" data-i18n="">Pengguna</span></a>
            <ul class="menu-content">
              
			  <li><a class="menu-item" href="../../../../index.php">Logout</a>
              </li>  
            </ul>
          </li>
        </ul>
      </div>
    </div>